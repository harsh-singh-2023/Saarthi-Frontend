
  # AI Smart Trip Planner

  This is a code bundle for AI Smart Trip Planner. The original project is available at https://www.figma.com/design/KWL2JaRxPe4l3xiQQ3rCnQ/AI-Smart-Trip-Planner.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  